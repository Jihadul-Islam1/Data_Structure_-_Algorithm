#include<bits/stdc++.h>
#include<stack>
using namespace std;

void stack_push(){
    stack<int>st;
    st.push(10);
    
    cout<<st.top()<<"\n";
}
int main(){
    stack_push();
}